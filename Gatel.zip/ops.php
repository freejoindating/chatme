<?php
/*
| -------------------------------------------------------------------------------
| Author            : G-Silvers
| Template Name     : G-Silvers V.3
| -------------------------------------------------------------------------------
*/
include('header.php'); ?>

      <div class="well text-center">
        <div style="text-align: center;"><img alt="ketauan ctrl+u" src="https://i.imgur.com/t7Z0nVI.gif" title="Ops ctrl+u">
<p><font size="46"  style="color:#A30202;">LOE MASUK SINI MAU NGECLONE YA??</font></p>
      </div>

<?php include('footer.php'); ?>