<?php
$oc_config = array (
    
    //================================================================================================
   

    "favicon"         => "favicon.gif" ,

    //================================================================================================

    "sitelogo"        => "Stream Free Movies & TV Shows",
    
    "sitename"        => "Stream Free Movies & TV Shows",

    "sitedescription" => "Browse and Watch all your favorite online movies &amp; series for free!",

    "sitekeywords"    => "full movie, full episode",

    "sitethemes"      => "g-stream",

    "offer_link1"     => "//look.ufinkln.com/offer?prod=21&ref=5259432",

    "offer_link2"     => "//look.ufinkln.com/offer?prod=604&ref=5259432",

    // "sport_offer"     => "",        // Jika Belum Di Include Plugin Sport nya gak bisa di gunakan

    "histatsID"       => "4511057",

    //================================================================================================

    "tvdb_search"     => "true",

    "cache"           => "true",

    "_seo"            => "true",

    "_stt"            => "true",

    "protect_content" => "true",       // disable klik kanan, block text, copy paste pada halaman LP

    "search_url"      => "search",

    "url_end"         => ".html",
    
    "category_url"    => "genre",
    
    "timezone"        => "Asia/Jakarta",

    "debug"           => "true",

);

$alt_country2 = array(
    /*
    |--------------------------------------------------------------------------
    | Contoh Penulisan Country Code
    |--------------------------------------------------------------------------
    | 'US', 'GB', 'UK'
    | Contoh Dibawah Menandakan Negara ID (Indonesia) dan MY (Malaysia) 
    | Offer Link nya akan di redirect ke Offer Kedua
    |
    */
   
   'ID', 'MY', 'MX', 'RU'
);